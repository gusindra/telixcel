
EmojiArea.DEFAULTS.assetPath = './assets/images';
