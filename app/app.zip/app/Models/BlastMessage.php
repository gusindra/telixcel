<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BlastMessage extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'msg_id',
        'user_id',
        'client_id',
        'status',
        'code',
        'message_content',
        'balance',
        'currency',
        'price',
        'msisdn',
        'title'
    ];

    protected $guarded = [];

}
