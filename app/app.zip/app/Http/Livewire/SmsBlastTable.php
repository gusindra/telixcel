<?php

namespace App\Http\Livewire;

use App\Models\BlastMessage;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\NumberColumn;
use Mediconesystems\LivewireDatatables\DateColumn;

class SmsBlastTable extends LivewireDatatable
{
    public $model = Client::class;
    public $userId;
    public $month;
    public $year;

    public function builder()
    {
        if(auth()->user()->super->first()->role == 'superadmin'){
            return BlastMessage::query();
        }
        return BlastMessage::query()->where('user_id', auth()->user()->currentTeam->user_id);
    }

    private function clientTbl(){
        return [
    		Column::name('msg_id')->label('Sending ID'),
    		Column::name('client_id')->label('Client'),
    		Column::name('message_content')->label('Message Content'),
    		Column::name('status')->label('Status'),
    		Column::name('msisdn')->label('Phone No'),
    		Column::name('created_at')->label('Creation Date')->sortBy('created_at', 'desc')
    	];
    }

    private function adminTbl(){
        return [
    		Column::name('user_id')->label('User ID')->filterable(),
    		Column::name('created_at')->label('Creation Date')->sortBy('created_at', 'desc')->filterable(),
    		Column::name('status')->label('Status')->filterable(),
    		Column::name('price')->label('Price'),
    		Column::name('msg_id')->label('Sending ID'),
    		Column::name('client_id')->label('Client'),
    		Column::name('message_content')->label('Message Content'),
    		Column::name('msisdn')->label('Phone No'),
    	];
    }

    public function columns()
    {
        if(auth()->user()->super->first()->role == 'superadmin'){
            return $this->adminTbl();
        }
        return $this->clientTbl();
    }
}
